﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code_Snippet_6
{
    class Program
    {
        static void Main(string[] args)
        {
            simpleInterest = principal * TimeoutException * rate / 100;
            eval = 25 + 6 - 78 * 5;
            num++;
        }
    }
}
