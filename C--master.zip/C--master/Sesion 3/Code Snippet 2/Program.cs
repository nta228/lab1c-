﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code_Snippet_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int side = 10;
            int height = 5;
            double area = 0.5 * side * height;
            Console.WriteLine("Area :", area);
        }
    }
}
