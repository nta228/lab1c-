﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code_Snippert_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int doSum = 4 + 3;
            Console.WriteLine("doSum:" + doSum);
        }
    }
}
