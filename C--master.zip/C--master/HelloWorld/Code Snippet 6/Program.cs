﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code_Snippet_6
{
    class Comments
    {
        static void Main(string[] args)
        {
            Console.WriteLine("C#");
        }
    }
}
