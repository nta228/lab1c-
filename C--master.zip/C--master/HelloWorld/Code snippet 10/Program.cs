﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code_snippet_10
{
    class Program
    {
        static void Main(string[] args)
        {
            static void Main(string[] args )
            {

            }
        }
    }
}
