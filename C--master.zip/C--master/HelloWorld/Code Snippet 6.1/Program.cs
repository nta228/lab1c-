﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code_Snippet_6._1
{
    class XMLComments
    {
        static void Main(string[] args)
        {
            Console.WriteLine("This program illustrates XML Comments");
        }
    }
}
