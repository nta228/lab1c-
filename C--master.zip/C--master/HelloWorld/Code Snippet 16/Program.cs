﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Code_Snippet_16
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 456;
            Console.WriteLine("{0:C}", num);
            Console.WriteLine("{0:D}", num);
            Console.WriteLine("{0:E}", num);
        }
    }
}
